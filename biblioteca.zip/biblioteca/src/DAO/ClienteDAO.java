
package DAO;

import Classes.Cliente;
import Classes.Livro;
import Conexao.util.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClienteDAO {
     private Connection conn;
    
    public ClienteDAO(){
        try{
            this.conn = Conexao.getConnection();
        } catch (Exception e){
            System.out.println(e.getMessage());;
        }
    }
    
    public ArrayList Listar(){
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Biblioteca = new ArrayList();
        
        try{
            String SQL = "SELECT * FROM clientes ORDER BY nome";
            connL = this.conn;
            
            ps = connL.prepareStatement (SQL);
            rs = ps.executeQuery();
            
            while (rs.next()){
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String email = rs.getString("email");
                String telefone = rs.getString("telefone");
                Biblioteca.add(new Cliente (id, nome, email, telefone));
                
            }
            
        } catch (SQLException sqle){
            System.out.println(sqle.getMessage());
        } finally {
            Conexao.close(connL, ps);
        }
        
        return Biblioteca;
    }
    
   public void inserir(Cliente cliente) {         
    PreparedStatement ps = null;
    Connection connL = null;        
    
    if (cliente == null){
        System.out.println("O objeto cliente não pode ser nulo.");
        return;
    }
    
    try {
        int novoId = proximoIdDisponivel(); 
        String SQL = "INSERT INTO clientes (id, nome, email, telefone) VALUES (?, ?, ?, ?)";
        
        connL = this.conn;
        ps = connL.prepareStatement(SQL);
        ps.setInt(1, novoId);
        ps.setString(2, cliente.getNome());
        ps.setString(3, cliente.getEmail());
        ps.setString(4, cliente.getTelefone());
        
        cliente.setId_cliente(novoId);
        ps.executeUpdate();

    } catch (SQLException sqle) {
        System.out.println("Erro ao inserir cliente: " + sqle);
    } finally {
        Conexao.close(connL, ps);
    }
}
    
    public int proximoIdDisponivel() {
    int proximoId = 1;
    String sql = "SELECT id FROM clientes ORDER BY id";
    
    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            int idAtual = rs.getInt("id");
            if (idAtual == proximoId) {
                proximoId++;
            } else {
                break; 
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return proximoId;
}
    
     public void atualizar(Cliente cliente) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (cliente == null) {
            System.out.println("O objeto cliente não pode ser nulo.");
            return;
        }

        try {
            String SQL = "UPDATE clientes SET nome = ?, email = ?, telefone = ? WHERE id = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setString(1, cliente.getNome());
            ps.setString(2, cliente.getEmail());
            ps.setString(3, cliente.getTelefone());
            ps.setInt(4, cliente.getId_cliente()); 

            ps.executeUpdate();

        } catch (SQLException sqle) {
            System.out.println("Erro ao editar cliente: " + sqle);
        } finally {
            Conexao.close(connL, ps);
        }
    }
     
      public void excluir(Cliente Cliente) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (Cliente == null) {
            System.out.println("O objeto cliente não pode ser nulo.");
        }

        try {
            String SQL = "DELETE FROM clientes WHERE id=?";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, Cliente.getId_cliente());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            System.out.println("Erro ao excluir Livro " + sqle);
        } finally {
            Conexao.close(connL, ps);
        }
    }
 public Cliente procurar(int id) {
    Cliente c = null;
    String sql = "SELECT * FROM clientes WHERE id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            c = new Cliente();
            c.setId_cliente(rs.getInt("id"));
            c.setNome(rs.getString("nome"));
            c.setEmail(rs.getString("email"));
            c.setTelefone(rs.getString("telefone"));
        }
        rs.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return c;
}
     
}
