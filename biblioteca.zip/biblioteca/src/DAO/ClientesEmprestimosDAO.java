/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Classes.Emprestimos;
import Classes.Livro;
import Classes.LivrosEmprestimos;
import Conexao.util.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ClientesEmprestimosDAO {

    private Connection conn;

    public ClientesEmprestimosDAO() {
        try {
            this.conn = (Connection) Conexao.getConnection();
        } catch (Exception e) {
            System.out.println("Erro de conexão: " + ":\n" + e.getMessage());
        }
    }

    public ArrayList<LivrosEmprestimos> listar(int codigo) throws ErpDAOException {
    PreparedStatement ps = null;
    Connection connL = null;
    ResultSet rs = null;
    ArrayList<LivrosEmprestimos> LivrosEmp = new ArrayList<>();

    try {
        String SQL = "SELECT livros.titulo, clientes.nome, emprestimos.tipo_movimentacao, emprestimos.data_movimentacao " +
                     "FROM livros, clientes, emprestimos " +
                     "WHERE livros.id=emprestimos.id_livro AND clientes.id=emprestimos.id_cliente AND livros.id = ?";
        connL = Conexao.getConnection();
        ps = connL.prepareStatement(SQL);
        ps.setInt(1, codigo); 
        rs = ps.executeQuery();
        
        while (rs.next()) {
            LivrosEmp.add(new LivrosEmprestimos(
                rs.getString("titulo"),
                rs.getString("nome"),
                rs.getString("tipo_movimentacao"),
                rs.getDate("data_movimentacao")
            ));
        }
    } catch(SQLException sqle) {
        throw new ErpDAOException("Erro ao listar Emprestimos: " + sqle.getMessage());
    } finally {
        Conexao.close(connL, ps, rs);
    }
    return LivrosEmp;
}
    
    public void inserir(Emprestimos emprestimo) throws ErpDAOException {
    PreparedStatement ps = null;
    Connection connL = null;

    if (emprestimo == null) {
        throw new ErpDAOException("O objeto emprestimo não pode ser nulo.");
    }

    try {
        int novoId = proximoIdDisponivel();

        String SQL = "INSERT INTO emprestimos (id, id_livro, id_cliente, tipo_movimentacao, data_movimentacao) "
                   + "VALUES (?, ?, ?, ?, ?)";
        connL = this.conn;
        ps = connL.prepareStatement(SQL);

        ps.setInt(1, novoId);
        ps.setInt(2, emprestimo.getId_livro());
        ps.setInt(3, emprestimo.getId_cliente());
        ps.setString(4, emprestimo.getTipo_movimentacao());

        java.sql.Date dataSQL = new java.sql.Date(emprestimo.getData_movimentacao().getTime());
        ps.setDate(5, dataSQL);

        emprestimo.setId(novoId); 
        ps.executeUpdate();

    } catch (SQLException sqle) {
        throw new ErpDAOException("Erro ao inserir um novo empréstimo: " + sqle.getMessage());
    } finally {
        Conexao.close(connL, ps);
    }
}
    
    
    
    public int proximoIdDisponivel() {
    int proximoId = 1;
    String sql = "SELECT id FROM emprestimos ORDER BY id";

    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            int idAtual = rs.getInt("id");
            if (idAtual == proximoId) {
                proximoId++;
            } else {
                break; // encontrou uma lacuna
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return proximoId;
}
    
    public ArrayList<Emprestimos> buscarPorCliente(int idCliente) {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection connL = null;

    ArrayList<Emprestimos> lista = new ArrayList<>();

    try {
        String SQL = "SELECT * FROM emprestimos WHERE id_cliente = ?";
        connL = this.conn;
        ps = connL.prepareStatement(SQL);
        ps.setInt(1, idCliente);
        rs = ps.executeQuery();

        while (rs.next()) {
            Emprestimos e = new Emprestimos();
            e.setId(rs.getInt("id")); 
            e.setId_cliente(rs.getInt("id_cliente"));
            e.setId_livro(rs.getInt("id_livro"));
            e.setTipo_movimentacao(rs.getString("tipo_movimentacao"));
            e.setData_movimentacao(rs.getDate("data_movimentacao"));

            lista.add(e);
        }

    } catch (SQLException e) {
        System.out.println("Erro ao buscar empréstimos por cliente: " + e.getMessage());
    } finally {
        Conexao.close(connL, ps);
    }

    return lista;
}
    
    public void excluir(Emprestimos e) throws ErpDAOException {
    PreparedStatement ps = null;
    Connection connL = null;

    try {
        String SQL = "DELETE FROM emprestimos WHERE id_cliente=? AND id_livro=? AND data_movimentacao=?";
        connL = this.conn;
        ps = connL.prepareStatement(SQL);
        ps.setInt(1, e.getId_cliente());
        ps.setInt(2, e.getId_livro());
        ps.setDate(3, new java.sql.Date(e.getData_movimentacao().getTime()));
        ps.executeUpdate();
    } catch (SQLException sqle) {
        throw new ErpDAOException("Erro ao excluir empréstimo: " + sqle.getMessage());
    } finally {
        Conexao.close(connL, ps);
    }
}

    public Emprestimos procurar(int id) throws ErpDAOException {
    Emprestimos e = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection connL = null;

    try {
        String SQL = "SELECT * FROM emprestimos WHERE id = ?";
        connL = this.conn;
        ps = connL.prepareStatement(SQL);
        ps.setInt(1, id);
        rs = ps.executeQuery();

        if (rs.next()) {
            e = new Emprestimos();
            e.setId(rs.getInt("id"));
            e.setId_livro(rs.getInt("id_livro"));
            e.setId_cliente(rs.getInt("id_cliente"));
            e.setTipo_movimentacao(rs.getString("tipo_movimentacao"));
            e.setData_movimentacao(rs.getDate("data_movimentacao"));
        }

    } catch (SQLException sqle) {
        throw new ErpDAOException("Erro ao procurar empréstimo: " + sqle.getMessage());
    } finally {
        Conexao.close(connL, ps);
    }

    return e;
}
    
   public boolean alterar(Emprestimos e) {
       System.out.println("ID: " + e.getId());
System.out.println("ID Cliente: " + e.getId_cliente());
System.out.println("ID Livro: " + e.getId_livro());
System.out.println("Tipo: " + e.getTipo_movimentacao());
System.out.println("Data: " + e.getData_movimentacao());
    String sql = "UPDATE emprestimos SET "
               + "id_livro = ?, "
               + "id_cliente = ?, "
               + "tipo_movimentacao = ?, "
               + "data_movimentacao = ? "
               + "WHERE id = ?";
    
    try (Connection connL = Conexao.getConnection();
         PreparedStatement ps = connL.prepareStatement(sql)) {
        
        ps.setInt(1, e.getId_livro());
        ps.setInt(2, e.getId_cliente());
        ps.setString(3, e.getTipo_movimentacao());
        ps.setDate(4, new java.sql.Date(e.getData_movimentacao().getTime()));
        ps.setInt(5, e.getId());

        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0;
        
    } catch (SQLException ex) {
    ex.printStackTrace(); 
    JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
    return false;
}
}
}