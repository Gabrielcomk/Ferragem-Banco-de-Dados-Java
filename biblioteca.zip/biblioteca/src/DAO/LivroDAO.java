package DAO;

import Classes.Livro;
import Conexao.util.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class LivroDAO {

    private Connection conn;

    public LivroDAO() {
        try {
            this.conn = Conexao.getConnection();
        } catch (Exception e) {
            System.out.println(e.getMessage());;
        }
    }

    public ArrayList<Livro> listar() {
    ArrayList<Livro> biblioteca = new ArrayList<>();
    try {
        String SQL = "SELECT * FROM livros ORDER BY id";
        PreparedStatement ps = conn.prepareStatement(SQL);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            int id_livro = rs.getInt("id");
            String titulo = rs.getString("titulo");
            String autor = rs.getString("autor");
            Date data_publicacao = rs.getDate("data_publicacao");
            String disponibilidade = rs.getString("disponibilidade");

            Livro l = new Livro(id_livro, titulo, autor, data_publicacao, disponibilidade);
            biblioteca.add(l);
            System.out.println("Carregado: " + titulo); 
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return biblioteca;
}

    public void inserir(Livro livro) {
    PreparedStatement ps = null;
    Connection connL = null;
    
    if (livro == null) {
        System.out.println("O objeto livro não pode ser nulo.");
        return;
    }

    try {
        int novoId = proximoIdDisponivel();
        livro.setId_livro(novoId); 

        String SQL = "INSERT INTO livros (id, titulo, autor, data_publicacao, disponibilidade) "
                   + "VALUES (?, ?, ?, ?, ?)";
        connL = this.conn;
        ps = connL.prepareStatement(SQL);

        ps.setInt(1, novoId);
        ps.setString(2, livro.getTitulo());
        ps.setString(3, livro.getAutor());

        java.util.Date dataJAVA = livro.getData_publicacao();
        java.sql.Date dataSQL = new java.sql.Date(dataJAVA.getTime());
        ps.setDate(4, dataSQL);
        ps.setString(5, livro.getDisponibilidade());

        ps.executeUpdate();

    } catch (SQLException sqle) {
        System.out.println("Erro ao inserir um novo livro: " + sqle);
    } finally {
        Conexao.close(connL, ps);
    }
}
    
    public int proximoIdDisponivel() {
    ArrayList<Integer> ids = listarIds();
    int id = 1;
    for (int ocupado : ids) {
        if (ocupado == id) {
            id++;
        } else if (ocupado > id) {
            break;
        }
    }
    return id;
}
    
    public ArrayList<Integer> listarIds() {
    ArrayList<Integer> ids = new ArrayList<>();
    String sql = "SELECT id FROM livros ORDER BY id ASC";

    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            ids.add(rs.getInt("id"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return ids;
}

    public void atualizar(Livro livro) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (livro == null) {
            System.out.println("O objeto livro não pode ser nulo.");
            return;
        }

        try {
            String SQL = "UPDATE livros SET titulo = ?, autor = ?, data_publicacao = ?, disponibilidade = ? WHERE id = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setString(1, livro.getTitulo());
            ps.setString(2, livro.getAutor());

            java.util.Date dataJAVA = livro.getData_publicacao();
            java.sql.Date dataSQL = new java.sql.Date(dataJAVA.getTime());
            ps.setDate(3, dataSQL);

            ps.setString(4, livro.getDisponibilidade());
            ps.setInt(5, livro.getId_livro()); 

            ps.executeUpdate();

        } catch (SQLException sqle) {
            System.out.println("Erro ao editar livro: " + sqle);
        } finally {
            Conexao.close(connL, ps);
        }
    }

    public void excluir(Livro Livro) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (Livro == null) {
            System.out.println("O objeto livro não pode ser nulo.");
        }

        try {
            String SQL = "DELETE FROM livros WHERE id=?";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, Livro.getId_livro());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            System.out.println("Erro ao excluir Livro " + sqle);
        } finally {
            Conexao.close(connL, ps);
        }
    }

    public Livro procurar(int id) {
    Livro l = null;
    String sql = "SELECT * FROM livros WHERE id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            l = new Livro();
            l.setId_livro(rs.getInt("id"));
            l.setTitulo(rs.getString("titulo"));
            l.setAutor(rs.getString("autor"));
            l.setData_publicacao(rs.getDate("data_publicacao"));
            l.setDisponibilidade(rs.getString("disponibilidade"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return l;
}

    
    
    
}
