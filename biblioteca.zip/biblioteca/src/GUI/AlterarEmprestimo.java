
package GUI;

import Classes.Cliente;
import Classes.Emprestimos;
import Classes.Livro;
import Classes.LivrosEmprestimos;
import DAO.ClienteDAO;
import DAO.ClientesEmprestimosDAO;
import DAO.LivroDAO;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;


public class AlterarEmprestimo extends javax.swing.JFrame {

    private Emprestimos emprestimoSelecionado;
    private ArrayList<Livro> listaLivros;
    private ArrayList<Cliente> listaClientes;
    private ClientesEmprestimosDAO emprestimoDAO;
    private LivroDAO livroDAO;
    private ClienteDAO clienteDAO;
    private int idLivroSelecionado;
    private int idClienteSelecionado;

    public AlterarEmprestimo(Emprestimos emprestimoSelecionado) {
        if (emprestimoSelecionado == null) {
            throw new IllegalArgumentException("Empréstimo não pode ser nulo");
        }
        
        this.emprestimoSelecionado = emprestimoSelecionado;
        this.emprestimoDAO = new ClientesEmprestimosDAO();
        this.livroDAO = new LivroDAO();
        this.clienteDAO = new ClienteDAO();
        
        initComponents();
        carregarDados();
    }

    private void carregarDados() {
        try {
            
            listaLivros = livroDAO.listar();
            listaClientes = clienteDAO.Listar();

            
            LivroComboBox.removeAllItems();
            ClienteComboBox.removeAllItems();

            
            for (Livro livro : listaLivros) {
                LivroComboBox.addItem(livro.getTitulo());
            }
            
            
            for (Cliente cliente : listaClientes) {
                ClienteComboBox.addItem(cliente.getNome());
            }
            
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            data.setText(sdf.format(emprestimoSelecionado.getData_movimentacao()));
            
            
            selecionarLivroAtual();
            
            
            selecionarClienteAtual();
            
            
            configurarTipoMovimentacao();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erro ao carregar dados: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void selecionarLivroAtual() {
        for (int i = 0; i < listaLivros.size(); i++) {
            if (listaLivros.get(i).getId_livro() == emprestimoSelecionado.getId_livro()) {
                LivroComboBox.setSelectedIndex(i);
                idLivroSelecionado = listaLivros.get(i).getId_livro();
                break;
            }
        }
    }

    private void selecionarClienteAtual() {
        for (int i = 0; i < listaClientes.size(); i++) {
            if (listaClientes.get(i).getId_cliente() == emprestimoSelecionado.getId_cliente()) {
                ClienteComboBox.setSelectedIndex(i);
                idClienteSelecionado = listaClientes.get(i).getId_cliente();
                break;
            }
        }
    }

    private void configurarTipoMovimentacao() {
        if (emprestimoSelecionado.getTipo_movimentacao().equalsIgnoreCase("Empréstimo")) {
            Emprestimo.setSelected(true);
        } else {
            Venda.setSelected(true);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code"> 
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel4 = new javax.swing.JLabel();
        LivroComboBox = new javax.swing.JComboBox<>();
        ClienteComboBox = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        data = new javax.swing.JTextField();
        Cancelar = new javax.swing.JButton();
        Alterar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Emprestimo = new javax.swing.JRadioButton();
        Venda = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ALTERAR LIVRO");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        LivroComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                LivroComboBoxItemStateChanged(evt);
            }
        });

        ClienteComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ClienteComboBoxItemStateChanged(evt);
            }
        });

        jLabel3.setText("Data");

        data.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dataActionPerformed(evt);
            }
        });

        Cancelar.setText("Cancelar");
        Cancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CancelarMouseClicked(evt);
            }
        });

        Alterar.setText("Alterar");
        Alterar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AlterarMouseClicked(evt);
            }
        });

        jLabel1.setText("Livro");

        jLabel2.setText("Cliente");

        buttonGroup1.add(Emprestimo);
        Emprestimo.setText("Empréstimo");

        buttonGroup1.add(Venda);
        Venda.setText("Venda");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(107, 107, 107)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Emprestimo)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ClienteComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(data, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LivroComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(121, Short.MAX_VALUE)
                .addComponent(Cancelar)
                .addGap(63, 63, 63)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Alterar)
                    .addComponent(Venda))
                .addGap(196, 196, 196))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(232, 232, 232)
                        .addComponent(jLabel4)
                        .addGap(64, 64, 64))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(LivroComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(ClienteComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(data, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Venda)
                            .addComponent(Emprestimo))
                        .addGap(54, 54, 54)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Alterar)
                    .addComponent(Cancelar))
                .addContainerGap(106, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       
    }//GEN-LAST:event_formWindowOpened

    private void LivroComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_LivroComboBoxItemStateChanged
        idLivroSelecionado = listaLivros.get(LivroComboBox.getSelectedIndex()).getId_livro();
    }//GEN-LAST:event_LivroComboBoxItemStateChanged

    private void ClienteComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ClienteComboBoxItemStateChanged
       idClienteSelecionado = listaClientes.get(ClienteComboBox.getSelectedIndex()).getId_cliente();
    }//GEN-LAST:event_ClienteComboBoxItemStateChanged

    private void dataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dataActionPerformed

    private void CancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CancelarMouseClicked
        dispose();
    }//GEN-LAST:event_CancelarMouseClicked

    private void AlterarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AlterarMouseClicked
      try {
           
            String tipoMovimentacao = Emprestimo.isSelected() ? "Empréstimo" : "Venda";
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date novaData = sdf.parse(data.getText());
            
           
            emprestimoSelecionado.setId_livro(idLivroSelecionado);
            emprestimoSelecionado.setId_cliente(idClienteSelecionado);
            emprestimoSelecionado.setTipo_movimentacao(tipoMovimentacao);
            emprestimoSelecionado.setData_movimentacao(novaData);
            
            
            boolean sucesso = emprestimoDAO.alterar(emprestimoSelecionado);
            
            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Empréstimo alterado com sucesso!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao alterar empréstimo.", 
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Formato de data inválido. Use dd/MM/aaaa.", 
                "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao alterar empréstimo: " + ex.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    
    }//GEN-LAST:event_AlterarMouseClicked

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Alterar;
    private javax.swing.JButton Cancelar;
    private static javax.swing.JComboBox<String> ClienteComboBox;
    private javax.swing.JRadioButton Emprestimo;
    private static javax.swing.JComboBox<String> LivroComboBox;
    private javax.swing.JRadioButton Venda;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JTextField data;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables

}
