
package GUI;

import Classes.Livro;
import DAO.ErpDAOException;
import DAO.LivroDAO;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class insereLivro extends javax.swing.JFrame {

  
    public insereLivro() {
        initComponents();
    }

    insereLivro(int codigo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        NO = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        RBM = new javax.swing.JRadioButton();
        RBF = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        DN = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        B1 = new javax.swing.JButton();
        OK = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        NO1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("INSERIR MEDICO");

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel1.setText("Digite o título:");

        NO.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        NO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NOActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel2.setText("Disponibilidade:");

        RBM.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        RBM.setText("Disponível");
        RBM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RBMActionPerformed(evt);
            }
        });

        RBF.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        RBF.setText("Indisponível");
        RBF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RBFActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setText("Digite a data de publicação");

        DN.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        DN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DNActionPerformed(evt);
            }
        });

        B1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        B1.setText("Cancelar");
        B1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B1ActionPerformed(evt);
            }
        });

        OK.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        OK.setText("Salvar");
        OK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OKMouseClicked(evt);
            }
        });
        OK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OKActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel5.setText("Digite o autor:");

        NO1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        NO1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NO1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 528, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(B1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(OK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(12, 12, 12))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(NO))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(NO1))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(DN))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(RBM)
                                .addGap(18, 18, 18)
                                .addComponent(RBF)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(NO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(NO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(DN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RBM)
                    .addComponent(RBF))
                .addGap(58, 58, 58)
                .addComponent(jLabel4)
                .addGap(24, 24, 24)
                .addComponent(B1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(OK)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NOActionPerformed
        
    }//GEN-LAST:event_NOActionPerformed

    private void RBMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RBMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RBMActionPerformed

    private void RBFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RBFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RBFActionPerformed

    private void B1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B1ActionPerformed
      dispose();
    }//GEN-LAST:event_B1ActionPerformed

    private void OKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OKMouseClicked
        String titulo, autor = null;
        Date data_publicacao = null;
        String disponibilidade = "";
        float preco;
        DateFormat dtOutput = new SimpleDateFormat("dd/MM/yyyy");
         
        if (DN.getText().equals("")) {
                data_publicacao = null;
            } else {
                try {
                    data_publicacao = dtOutput.parse(DN.getText());
                } catch (ParseException ex) {
                    System.out.println("Erro na conversão da data");
                }
            }

        
        if (NO.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Você precisa digitar o titulo");
        } else if ((RBF.isSelected() == false) && (RBM.isSelected() == false)) {
            JOptionPane.showMessageDialog(rootPane, "Você precisa selecionar a disponibilidade");
        } else {
            
            titulo = NO.getText();
            autor = NO1.getText();
            
            if (RBM.isSelected() == true) {
                disponibilidade = "Disponível";
            }
            else if (RBF.isSelected() == true) {
                disponibilidade = "Indisponível";
            }
            

            
            
            
            L.setTitulo(titulo);
            L.setAutor(autor);
            L.setData_publicacao(data_publicacao);
            L.setDisponibilidade(disponibilidade);
            
          

            LivroDAO LDAO = new LivroDAO();
            LDAO.inserir(L);
            JOptionPane.showMessageDialog(rootPane, "Inserção efetuada com sucesso!!");
            dispose();
        }
        
        

    }//GEN-LAST:event_OKMouseClicked

    private void OKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OKActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OKActionPerformed

    private void DNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DNActionPerformed

    private void NO1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NO1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NO1ActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton B1;
    private javax.swing.JTextField DN;
    private javax.swing.JTextField NO;
    private javax.swing.JTextField NO1;
    private javax.swing.JButton OK;
    private javax.swing.JRadioButton RBF;
    private javax.swing.JRadioButton RBM;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
    private Livro L = new Livro ();
}
