
package GUI;

import Classes.Livro;
import DAO.ErpDAOException;
import DAO.LivroDAO;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class ExcluirLivro extends javax.swing.JFrame {
    
    private Livro liv = new Livro();
    int id, posi;
    private static ArrayList<Livro> livro = new ArrayList<>();
    private static DefaultListModel Valores = new DefaultListModel();
    private static int codigo = 0;
    private static int posicao, posiliv;

    public ExcluirLivro() {
        initComponents();
        carregarTitulosComboBox();
    }
    
   private void carregarTitulosComboBox() {
    try {
        LivroDAO livroDAO = new LivroDAO();
        ArrayList<Livro> livros = livroDAO.listar();

        TituloComboBox.removeAllItems();
        livro.clear();

        for (Livro l : livros) {
            TituloComboBox.addItem(l.getTitulo());
            livro.add(l);
        }

        
        if (!livro.isEmpty()) {
            id = livro.get(0).getId_livro();
            TituloComboBox.setSelectedIndex(0);
            carregar();
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Erro ao carregar títulos: " + e.getMessage());
    }
}
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel4 = new javax.swing.JLabel();
        DataPub = new javax.swing.JTextField();
        Cancelar = new javax.swing.JButton();
        Excluir = new javax.swing.JButton();
        TituloComboBox = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Autor = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Titulo = new javax.swing.JTextField();
        DisponivelButton = new javax.swing.JRadioButton();
        IndisponivelButton = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ALTERAR LIVRO");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        DataPub.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        DataPub.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DataPubActionPerformed(evt);
            }
        });

        Cancelar.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        Cancelar.setText("Cancelar");
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });

        Excluir.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        Excluir.setText("Excluir");
        Excluir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExcluirMouseClicked(evt);
            }
        });
        Excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirActionPerformed(evt);
            }
        });

        TituloComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                TituloComboBoxItemStateChanged(evt);
            }
        });
        TituloComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TituloComboBoxActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel5.setText("Digite o autor:");

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel1.setText("Digite o título:");

        Autor.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        Autor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AutorActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel2.setText("Disponibilidade:");

        Titulo.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        Titulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TituloActionPerformed(evt);
            }
        });

        buttonGroup1.add(DisponivelButton);
        DisponivelButton.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        DisponivelButton.setText("Disponível");
        DisponivelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisponivelButtonActionPerformed(evt);
            }
        });

        buttonGroup1.add(IndisponivelButton);
        IndisponivelButton.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        IndisponivelButton.setText("Indisponível");
        IndisponivelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IndisponivelButtonActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setText("Digite a data de publicação");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Excluir, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Cancelar))
                        .addGap(66, 66, 66))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(TituloComboBox, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(Titulo))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(Autor, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(DisponivelButton)
                                .addGap(18, 18, 18)
                                .addComponent(IndisponivelButton))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(DataPub)))
                        .addContainerGap(87, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(232, 232, 232)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TituloComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Autor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(DataPub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DisponivelButton)
                    .addComponent(IndisponivelButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 108, Short.MAX_VALUE)
                .addComponent(Cancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Excluir)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DataPubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DataPubActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DataPubActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        dispose();
    }//GEN-LAST:event_CancelarActionPerformed

    private void ExcluirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExcluirMouseClicked
          Livro L = new Livro();
        Date data_publicacao = null;
        String disponibilidade = "";
        String titulo, autor;
        
        DateFormat dtOutput = new SimpleDateFormat("dd/MM/yyyy");
        L.setId_livro(id);
        if (Titulo.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "O Campo Titulo não pode estar vazio");
        } else if (Autor.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "O Campo Autor não pode estar vazio");
}
            L.setTitulo(Titulo.getText());
            L.setAutor(Autor.getText());
            if (DisponivelButton.isSelected() == true) {
                disponibilidade = "Disponível";
            }
            if (IndisponivelButton.isSelected() == true) {
                disponibilidade = "Indisponível";
            }
            L.setDisponibilidade(disponibilidade);
            if (DataPub.getText().equals("")) {
                data_publicacao = null;
            } else {
                try {
                    data_publicacao = dtOutput.parse(DataPub.getText());
                } catch (ParseException ex) {
                    System.out.println("Erro na conversão da data");
                }
            }
            L.setData_publicacao(data_publicacao);
            LivroDAO LDAO = new LivroDAO();
            int confirmar = JOptionPane.showConfirmDialog(null, "Confirmar", "Vocẽ tem certeza", JOptionPane.OK_CANCEL_OPTION);
            if (confirmar == 0) {
                LDAO.excluir(L);
                JOptionPane.showMessageDialog(rootPane, "Exclusão efetuada");
                dispose();
            } else {

            }
    }//GEN-LAST:event_ExcluirMouseClicked

    private void ExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirActionPerformed

    }//GEN-LAST:event_ExcluirActionPerformed

    private void AutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AutorActionPerformed

    private void TituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TituloActionPerformed

    }//GEN-LAST:event_TituloActionPerformed

    private void DisponivelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisponivelButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DisponivelButtonActionPerformed

    private void IndisponivelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IndisponivelButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IndisponivelButtonActionPerformed

    private void TituloComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TituloComboBoxActionPerformed
  
    }//GEN-LAST:event_TituloComboBoxActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        carregarTitulosComboBox();
        carregar();
    }//GEN-LAST:event_formWindowOpened

    private void TituloComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_TituloComboBoxItemStateChanged

    posi = TituloComboBox.getSelectedIndex();
    
    if (posi >= 0 && posi < livro.size()) {
        id = livro.get(posi).getId_livro();
        carregar();
    }
    }//GEN-LAST:event_TituloComboBoxItemStateChanged

   

     public void carregar() {
        LivroDAO LDAO = new LivroDAO();
        L = LDAO.procurar(id);
        Titulo.setText(L.getTitulo());
        Autor.setText(L.getAutor());
        if (DisponivelButton.isSelected() && IndisponivelButton.isSelected()) {
            DisponivelButton.setSelected(false);
            IndisponivelButton.setSelected(false);
        }
        if (L.getDisponibilidade() == "Disponível") {
            DisponivelButton.setSelected(true);
        }
        if ("Disponível".equals(L.getDisponibilidade())) {
    DisponivelButton.setSelected(true);
} else if ("Indisponível".equals(L.getDisponibilidade())) {
    IndisponivelButton.setSelected(true);
}
        if (L.getData_publicacao() == null) {
            DataPub.setText("");
        } else {
            Date dn = null;
            String aux = "";
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            dn = L.getData_publicacao();
            aux = sdf.format(dn);

            DataPub.setText(aux);
        }
    }
     
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Autor;
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField DataPub;
    private javax.swing.JRadioButton DisponivelButton;
    private javax.swing.JButton Excluir;
    private javax.swing.JRadioButton IndisponivelButton;
    private javax.swing.JTextField Titulo;
    private javax.swing.JComboBox<String> TituloComboBox;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
    private Livro L = new Livro ();
}
