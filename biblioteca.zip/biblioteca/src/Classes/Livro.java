package Classes;

import java.util.Date;

public class Livro {

    public static Object get(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    int id_livro;
    String titulo;
    String autor;
    Date data_publicacao;
    String disponibilidade;
    float preco;

    public int getId_livro() {
        return id_livro;
    }

    public void setId_livro(int id_livro) {
        this.id_livro = id_livro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public Date getData_publicacao() {
        return data_publicacao;
    }

    public void setData_publicacao(Date data_publicacao) {
        this.data_publicacao = data_publicacao;
    }

    public String getDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(String disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }
    
    


    public Livro(int id_livro, String titulo, String autor, Date data_publicacao, String disponibilidade) {
        this.id_livro = id_livro;
        this.titulo = titulo;
        this.autor = autor;
        this.data_publicacao = data_publicacao;
        this.disponibilidade = disponibilidade;
        this.preco = preco;
    }

    public Livro() {
    }

    

    
    
    
    
}
