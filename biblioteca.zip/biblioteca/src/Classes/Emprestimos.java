package Classes;

import java.util.Date;

public class Emprestimos {
    private int id;  
    private int id_livro;
    private int id_cliente;
    private String tipo_movimentacao;
    private Date data_movimentacao;
    
    
    public Emprestimos() {
    }
    
    
    public Emprestimos(int id, int id_livro, int id_cliente, 
                      String tipo_movimentacao, Date data_movimentacao) {
        this.id = id;
        this.id_livro = id_livro;
        this.id_cliente = id_cliente;
        this.tipo_movimentacao = tipo_movimentacao;
        this.data_movimentacao = data_movimentacao;
    }
    
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getId_livro() {
        return id_livro;
    }
    
    public void setId_livro(int id_livro) {
        this.id_livro = id_livro;
    }
    
    public int getId_cliente() {
        return id_cliente;
    }
    
    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }
    
    public String getTipo_movimentacao() {
        return tipo_movimentacao;
    }
    
    public void setTipo_movimentacao(String tipo_movimentacao) {
        if(tipo_movimentacao == null || tipo_movimentacao.trim().isEmpty()) {
            throw new IllegalArgumentException("Tipo de movimentação não pode ser vazio");
        }
        this.tipo_movimentacao = tipo_movimentacao;
    }
    
    public Date getData_movimentacao() {
        return data_movimentacao != null ? new Date(data_movimentacao.getTime()) : null;
    }
    
    public void setData_movimentacao(Date data_movimentacao) {
        if(data_movimentacao == null) {
            throw new IllegalArgumentException("Data de movimentação não pode ser nula");
        }
        this.data_movimentacao = new Date(data_movimentacao.getTime());
    }
    
    @Override
    public String toString() {
        return "Emprestimo [ID=" + id + ", Livro=" + id_livro + ", Cliente=" + id_cliente + ", Tipo=" + tipo_movimentacao + ", Data=" + data_movimentacao + "]";
    }

}