package GUI;

import GUI.Listagem.ListarFornecedor;
import GUI.Listagem.ListarEstoque;
import GUI.Listagem.ListarClientesParaPedidos;
import GUI.Insercao.ListarClientesParaInserirPedido;
import GUI.Exclusao.ListarClientesParaExcluir;
import GUI.Alteracao.ListarClientesParaAlterar;
import GUI.Alteracao.ListarEntregadorParaAlterar;
import GUI.Alteracao.ListarEstoqueParaAlterar;

import GUI.Exclusao.ListarClientesParaExcluirPedidos;
import GUI.Exclusao.ListarEstoqueParaExcluir;
import GUI.Alteracao.ListarFornecedorParaAlterar;
import GUI.Exclusao.ListarEntregadorParaExcluir;
import GUI.Exclusao.ListarFornecedorParaExcluir;
import GUI.Insercao.InserirCliente;
import GUI.Insercao.InserirEntregador;
import GUI.Insercao.InserirEstoque;
import GUI.Insercao.InserirFornecedor;
import GUI.Listagem.ListarEntregador;
import GUI.Listagem.ListarNf;
import javax.swing.JFrame;

public class Principal extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Principal.class.getName());

    public Principal() {
        initComponents();
        menuClientes.setMnemonic('Z'); // Atalho Alt+C
        menuClientes.setDisplayedMnemonicIndex(1); // Sublinhar a letra C
        menuPedidos.setMnemonic('X');
        menuPedidos.setDisplayedMnemonicIndex(1);
        menuFornecedor.setMnemonic('C');
        menuFornecedor.setDisplayedMnemonicIndex(1);
        menuEstoque.setMnemonic('V');
        menuEstoque.setDisplayedMnemonicIndex(1);
        menuEntregador.setMnemonic('A');
        menuEntregador.setDisplayedMnemonicIndex(1);
        menuNotaFiscal.setMnemonic('S');
        menuNotaFiscal.setDisplayedMnemonicIndex(1);
        menuFerramentas.setMnemonic('D');
        menuFerramentas.setDisplayedMnemonicIndex(1);
        this.setLocationRelativeTo(null);
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Sair = new javax.swing.JToggleButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuClientes = new javax.swing.JMenu();
        ListarCliente = new javax.swing.JMenuItem();
        InserirCliente = new javax.swing.JMenuItem();
        AlterarCliente = new javax.swing.JMenuItem();
        ListarCliente2 = new javax.swing.JMenuItem();
        menuPedidos = new javax.swing.JMenu();
        ListarPedido = new javax.swing.JMenuItem();
        InserirPedido = new javax.swing.JMenuItem();
        ExcluirPedido = new javax.swing.JMenuItem();
        menuFornecedor = new javax.swing.JMenu();
        ListarFornecedor = new javax.swing.JMenuItem();
        InserirFornecedor = new javax.swing.JMenuItem();
        AlterarFornecedor = new javax.swing.JMenuItem();
        ExcluirFornecedor = new javax.swing.JMenuItem();
        menuEstoque = new javax.swing.JMenu();
        ListarEstoque = new javax.swing.JMenuItem();
        InserirEstoque = new javax.swing.JMenuItem();
        AlterarEstoque = new javax.swing.JMenuItem();
        ExcluirEstoque = new javax.swing.JMenuItem();
        menuEntregador = new javax.swing.JMenu();
        ListaEntregador = new javax.swing.JMenuItem();
        InserirEntregador = new javax.swing.JMenuItem();
        AlterarEntregador = new javax.swing.JMenuItem();
        ExcluirEntregador = new javax.swing.JMenuItem();
        menuNotaFiscal = new javax.swing.JMenu();
        NotaFiscalListar = new javax.swing.JMenuItem();
        menuFerramentas = new javax.swing.JMenu();
        AbrirConfiguracao = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Sair.setText("Sair");
        Sair.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SairMouseClicked(evt);
            }
        });
        Sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SairActionPerformed(evt);
            }
        });

        jLabel1.setText("ALT + botões");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(248, 248, 248)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(Sair, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(254, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(78, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(64, 64, 64)
                .addComponent(Sair)
                .addGap(130, 130, 130))
        );

        menuClientes.setText("(Z)Clientes");

        ListarCliente.setText("Listar Cliente/Pedido");
        ListarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListarClienteActionPerformed(evt);
            }
        });
        menuClientes.add(ListarCliente);

        InserirCliente.setText("Inserir");
        InserirCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserirClienteActionPerformed(evt);
            }
        });
        menuClientes.add(InserirCliente);

        AlterarCliente.setText("Alterar");
        AlterarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlterarClienteActionPerformed(evt);
            }
        });
        menuClientes.add(AlterarCliente);

        ListarCliente2.setText("Excluir");
        ListarCliente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListarCliente2ActionPerformed(evt);
            }
        });
        menuClientes.add(ListarCliente2);

        jMenuBar1.add(menuClientes);

        menuPedidos.setText("(X)Pedidos");

        ListarPedido.setText("Listar");
        ListarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListarPedidoActionPerformed(evt);
            }
        });
        menuPedidos.add(ListarPedido);

        InserirPedido.setText("Inserir");
        InserirPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserirPedidoActionPerformed(evt);
            }
        });
        menuPedidos.add(InserirPedido);

        ExcluirPedido.setText("Excluir");
        ExcluirPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirPedidoActionPerformed(evt);
            }
        });
        menuPedidos.add(ExcluirPedido);

        jMenuBar1.add(menuPedidos);

        menuFornecedor.setText("(C)Fornecedor");

        ListarFornecedor.setText("Listar");
        ListarFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListarFornecedorActionPerformed(evt);
            }
        });
        menuFornecedor.add(ListarFornecedor);

        InserirFornecedor.setText("Inserir");
        InserirFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserirFornecedorActionPerformed(evt);
            }
        });
        menuFornecedor.add(InserirFornecedor);

        AlterarFornecedor.setText("Alterar");
        AlterarFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlterarFornecedorActionPerformed(evt);
            }
        });
        menuFornecedor.add(AlterarFornecedor);

        ExcluirFornecedor.setText("Excluir");
        ExcluirFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirFornecedorActionPerformed(evt);
            }
        });
        menuFornecedor.add(ExcluirFornecedor);

        jMenuBar1.add(menuFornecedor);

        menuEstoque.setText("(V)Estoque");

        ListarEstoque.setText("Listar");
        ListarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListarEstoqueActionPerformed(evt);
            }
        });
        menuEstoque.add(ListarEstoque);

        InserirEstoque.setText("Inserir");
        InserirEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserirEstoqueActionPerformed(evt);
            }
        });
        menuEstoque.add(InserirEstoque);

        AlterarEstoque.setText("Alterar");
        AlterarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlterarEstoqueActionPerformed(evt);
            }
        });
        menuEstoque.add(AlterarEstoque);

        ExcluirEstoque.setText("Excluir");
        ExcluirEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirEstoqueActionPerformed(evt);
            }
        });
        menuEstoque.add(ExcluirEstoque);

        jMenuBar1.add(menuEstoque);

        menuEntregador.setText("(A)Entregador");

        ListaEntregador.setText("Listar");
        ListaEntregador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListaEntregadorActionPerformed(evt);
            }
        });
        menuEntregador.add(ListaEntregador);

        InserirEntregador.setText("Inserir");
        InserirEntregador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserirEntregadorActionPerformed(evt);
            }
        });
        menuEntregador.add(InserirEntregador);

        AlterarEntregador.setText("Alterar");
        AlterarEntregador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlterarEntregadorActionPerformed(evt);
            }
        });
        menuEntregador.add(AlterarEntregador);

        ExcluirEntregador.setText("Excluir");
        ExcluirEntregador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirEntregadorActionPerformed(evt);
            }
        });
        menuEntregador.add(ExcluirEntregador);

        jMenuBar1.add(menuEntregador);

        menuNotaFiscal.setText("(S)Nota Fiscal");

        NotaFiscalListar.setText("Listar");
        NotaFiscalListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NotaFiscalListarActionPerformed(evt);
            }
        });
        menuNotaFiscal.add(NotaFiscalListar);

        jMenuBar1.add(menuNotaFiscal);

        menuFerramentas.setText("(D)Ferramentas");

        AbrirConfiguracao.setText("Configurações");
        AbrirConfiguracao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AbrirConfiguracaoActionPerformed(evt);
            }
        });
        menuFerramentas.add(AbrirConfiguracao);

        jMenuBar1.add(menuFerramentas);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SairMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SairMouseClicked
        dispose();
        dispose();
    }//GEN-LAST:event_SairMouseClicked

    private void SairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SairActionPerformed
        dispose();
        dispose();
    }//GEN-LAST:event_SairActionPerformed

    private void ListarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListarClienteActionPerformed
    JFrame ListarClientes = new ListarClientesParaPedidos(); 
    ListarClientes.setLocationRelativeTo(rootPane); 
    ListarClientes.setVisible(true);
    }//GEN-LAST:event_ListarClienteActionPerformed

    private void InserirClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserirClienteActionPerformed
        JFrame InserirCliente = new InserirCliente(); 
    InserirCliente.setLocationRelativeTo(rootPane); 
    InserirCliente.setVisible(true);
    }//GEN-LAST:event_InserirClienteActionPerformed

    private void AlterarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlterarClienteActionPerformed
       JFrame ListarClientesParaAlterar = new ListarClientesParaAlterar(); 
    ListarClientesParaAlterar.setLocationRelativeTo(rootPane); 
    ListarClientesParaAlterar.setVisible(true);
    }//GEN-LAST:event_AlterarClienteActionPerformed

    private void ListarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListarPedidoActionPerformed
      JFrame ListarClientes = new ListarClientesParaPedidos(); 
    ListarClientes.setLocationRelativeTo(rootPane); 
    ListarClientes.setVisible(true);
    }//GEN-LAST:event_ListarPedidoActionPerformed

    private void InserirPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserirPedidoActionPerformed
        JFrame ListarClientes = new ListarClientesParaInserirPedido(); 
    ListarClientes.setLocationRelativeTo(rootPane); 
    ListarClientes.setVisible(true);
    }//GEN-LAST:event_InserirPedidoActionPerformed

    private void ExcluirPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirPedidoActionPerformed
        JFrame ListarClientesParaExcluirPedidos = new ListarClientesParaExcluirPedidos(); 
    ListarClientesParaExcluirPedidos.setLocationRelativeTo(rootPane); 
    ListarClientesParaExcluirPedidos.setVisible(true);
    }//GEN-LAST:event_ExcluirPedidoActionPerformed

    private void ListarCliente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListarCliente2ActionPerformed
        JFrame ListarClientesParaExcluir = new ListarClientesParaExcluir(); 
    ListarClientesParaExcluir.setLocationRelativeTo(rootPane); 
    ListarClientesParaExcluir.setVisible(true);
    }//GEN-LAST:event_ListarCliente2ActionPerformed

    private void ListarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListarEstoqueActionPerformed
        JFrame ListarEstoque = new ListarEstoque(); 
    ListarEstoque.setLocationRelativeTo(rootPane); 
    ListarEstoque.setVisible(true);
    }//GEN-LAST:event_ListarEstoqueActionPerformed

    private void InserirEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserirEstoqueActionPerformed
        JFrame InserirEstoque = new InserirEstoque(); 
    InserirEstoque.setLocationRelativeTo(rootPane); 
    InserirEstoque.setVisible(true);
    }//GEN-LAST:event_InserirEstoqueActionPerformed

    private void AlterarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlterarEstoqueActionPerformed
        JFrame ListarEstoqueParaAlterar = new ListarEstoqueParaAlterar(); 
    ListarEstoqueParaAlterar.setLocationRelativeTo(rootPane); 
    ListarEstoqueParaAlterar.setVisible(true);
    }//GEN-LAST:event_AlterarEstoqueActionPerformed

    private void ExcluirEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirEstoqueActionPerformed
        JFrame ListarEstoqueParaExcluir = new ListarEstoqueParaExcluir(); 
    ListarEstoqueParaExcluir.setLocationRelativeTo(rootPane); 
    ListarEstoqueParaExcluir.setVisible(true);
    }//GEN-LAST:event_ExcluirEstoqueActionPerformed

    private void ListarFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListarFornecedorActionPerformed
        JFrame ListarFornecedor = new ListarFornecedor(); 
    ListarFornecedor.setLocationRelativeTo(rootPane); 
    ListarFornecedor.setVisible(true);
    }//GEN-LAST:event_ListarFornecedorActionPerformed

    private void InserirFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserirFornecedorActionPerformed
       JFrame InserirFornecedor = new InserirFornecedor(); 
    InserirFornecedor.setLocationRelativeTo(rootPane); 
    InserirFornecedor.setVisible(true);
    }//GEN-LAST:event_InserirFornecedorActionPerformed

    private void AlterarFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlterarFornecedorActionPerformed
        JFrame ListarFornecedorParaAlterar = new ListarFornecedorParaAlterar(); 
    ListarFornecedorParaAlterar.setLocationRelativeTo(rootPane); 
    ListarFornecedorParaAlterar.setVisible(true);
    }//GEN-LAST:event_AlterarFornecedorActionPerformed

    private void ExcluirFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirFornecedorActionPerformed
        JFrame ListarFornecedorParaExcluir = new ListarFornecedorParaExcluir(); 
    ListarFornecedorParaExcluir.setLocationRelativeTo(rootPane); 
    ListarFornecedorParaExcluir.setVisible(true);
    }//GEN-LAST:event_ExcluirFornecedorActionPerformed

    private void ListaEntregadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListaEntregadorActionPerformed
       JFrame ListarEntregador = new ListarEntregador(); 
    ListarEntregador.setLocationRelativeTo(rootPane); 
    ListarEntregador.setVisible(true);
    }//GEN-LAST:event_ListaEntregadorActionPerformed

    private void InserirEntregadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserirEntregadorActionPerformed
         JFrame InserirEntregador = new InserirEntregador(); 
    InserirEntregador.setLocationRelativeTo(rootPane); 
    InserirEntregador.setVisible(true);
    }//GEN-LAST:event_InserirEntregadorActionPerformed

    private void AlterarEntregadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlterarEntregadorActionPerformed
        JFrame ListarEntregadorParaAlterar = new ListarEntregadorParaAlterar(); 
    ListarEntregadorParaAlterar.setLocationRelativeTo(rootPane); 
    ListarEntregadorParaAlterar.setVisible(true);
    }//GEN-LAST:event_AlterarEntregadorActionPerformed

    private void ExcluirEntregadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirEntregadorActionPerformed
        JFrame ListarEntregadorParaExcluir = new ListarEntregadorParaExcluir(); 
    ListarEntregadorParaExcluir.setLocationRelativeTo(rootPane); 
    ListarEntregadorParaExcluir.setVisible(true);
    }//GEN-LAST:event_ExcluirEntregadorActionPerformed

    private void AbrirConfiguracaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AbrirConfiguracaoActionPerformed
        JFrame Configuracoes = new Configuracoes();
        Configuracoes.setLocationRelativeTo(rootPane);
        Configuracoes.setVisible(true);
    }//GEN-LAST:event_AbrirConfiguracaoActionPerformed

    private void NotaFiscalListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NotaFiscalListarActionPerformed
         JFrame ListarNf = new ListarNf();
        ListarNf.setLocationRelativeTo(rootPane);
        ListarNf.setVisible(true);
    }//GEN-LAST:event_NotaFiscalListarActionPerformed

 
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new Principal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AbrirConfiguracao;
    private javax.swing.JMenuItem AlterarCliente;
    private javax.swing.JMenuItem AlterarEntregador;
    private javax.swing.JMenuItem AlterarEstoque;
    private javax.swing.JMenuItem AlterarFornecedor;
    private javax.swing.JMenuItem ExcluirEntregador;
    private javax.swing.JMenuItem ExcluirEstoque;
    private javax.swing.JMenuItem ExcluirFornecedor;
    private javax.swing.JMenuItem ExcluirPedido;
    private javax.swing.JMenuItem InserirCliente;
    private javax.swing.JMenuItem InserirEntregador;
    private javax.swing.JMenuItem InserirEstoque;
    private javax.swing.JMenuItem InserirFornecedor;
    private javax.swing.JMenuItem InserirPedido;
    private javax.swing.JMenuItem ListaEntregador;
    private javax.swing.JMenuItem ListarCliente;
    private javax.swing.JMenuItem ListarCliente2;
    private javax.swing.JMenuItem ListarEstoque;
    private javax.swing.JMenuItem ListarFornecedor;
    private javax.swing.JMenuItem ListarPedido;
    private javax.swing.JMenuItem NotaFiscalListar;
    private javax.swing.JToggleButton Sair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenu menuClientes;
    private javax.swing.JMenu menuEntregador;
    private javax.swing.JMenu menuEstoque;
    private javax.swing.JMenu menuFerramentas;
    private javax.swing.JMenu menuFornecedor;
    private javax.swing.JMenu menuNotaFiscal;
    private javax.swing.JMenu menuPedidos;
    // End of variables declaration//GEN-END:variables
}
